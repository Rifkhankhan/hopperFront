import React from 'react'

const MobileFarm = () => {
	return <div>MobileFarm</div>
}

export default MobileFarm
