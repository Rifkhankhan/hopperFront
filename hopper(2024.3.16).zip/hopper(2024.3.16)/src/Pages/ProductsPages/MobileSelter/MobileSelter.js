import React from 'react'

const MobileSelter = props => {
	return <div></div>
}

export default MobileSelter
